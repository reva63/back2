export interface ICallbackQuery {
    readonly code: string;
    readonly state: string;
}
