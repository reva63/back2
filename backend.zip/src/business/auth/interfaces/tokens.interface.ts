export interface ITokensInterface {
    accessToken: string;
    refreshToken: string;
}
