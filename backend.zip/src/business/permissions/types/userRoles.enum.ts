export enum UserRoles {
    Participant = 'participant',
    Expert = 'expert',
    Moderator = 'moderator',
    Manager = 'manager',
    Ambassador = 'ambassador',
}
