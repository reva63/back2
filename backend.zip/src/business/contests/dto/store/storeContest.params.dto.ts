import { IParamsDto } from 'src/core/abstract/base/dto/paramsDto.interface';

export class StoreContestParamsDto implements IParamsDto {}
