import { IParamsDto } from 'src/core/abstract/base/dto/paramsDto.interface';

export class StoreCategoryParamsDto implements IParamsDto {}
