export const getRoomId = (chatId: number): string => {
    return chatId.toString();
};
