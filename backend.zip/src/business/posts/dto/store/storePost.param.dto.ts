import { IParamsDto } from 'src/core/abstract/base/dto/paramsDto.interface';

export class StorePostParamsDto implements IParamsDto {}
