export interface IAuthUser {
    id: number;
    iat: number;
    exp: number;
}
