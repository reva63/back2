export enum AttributeTypes {
    Social = 'social',
    Profile = 'profile',
    Text = 'text',
    List = 'list',
    Link = 'link',
    File = 'file',
    Special = 'special',
}
