export enum MimeTypes {
    PDF = 'application/pdf',
    JSON = 'application/json',
    PLAIN = 'text/plain',
}
