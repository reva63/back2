export enum CitizenshipTypes {
    RF = 'rf',
}
