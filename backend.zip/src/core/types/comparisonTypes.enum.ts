export enum ComparisonTypes {
    Equals = '=',
    Bigger = '>',
    Smaller = '<',
    In = 'in',
}
