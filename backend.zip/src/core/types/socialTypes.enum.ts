export enum SocialTypes {
    Telegram = 'telegram',
    VK = 'vk',
    Youtube = 'youtube',
    Rutube = 'rutube',
    Other = 'other',
}
