export enum ParagraphTypes {
    Text = 'text',
    Image = 'image',
}
