export enum NotificationTypes {
    Moderator = 'moderator',
    System = 'system',
    Banner = 'banner',
    Other = 'other',
}
